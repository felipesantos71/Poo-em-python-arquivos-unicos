package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Motorista extends Funcionario{
    //Definindo atributos
    private String carteiroDeHabilitacao;
    
    //Método construtor
    public Motorista(String carteiroDeHabilitacao, String nome, String cpf, String rg, String dataNascimento, double salario, Sexo sexo, Setor setor, Endereco endereco) {
        super(nome, cpf, rg, dataNascimento, salario, sexo, setor, endereco);
        this.carteiroDeHabilitacao = carteiroDeHabilitacao;
    }
    
    //Método getter e setter
    public String getCarteiroDeHabilitacao() {
        return carteiroDeHabilitacao;
    }

    public void setCarteiroDeHabilitacao(String carteiroDeHabilitacao) {
        this.carteiroDeHabilitacao = carteiroDeHabilitacao;
    }
    
    //Método tostring()
    @Override
    public String toString() {
        return "\nMotorista" + 
                super.toString() +
                "\nCarteiro de Habilitacao: " + carteiroDeHabilitacao;
    }

    //Método da interface salario final
    @Override
    public double getSalarioFinal() {
        double salarioFinal = 0;
        salarioFinal = salario;
        return salarioFinal;
    }
}
