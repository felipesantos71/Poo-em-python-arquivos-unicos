package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public interface Contratacao {
    public void admitir(Funcionario funcionario);
    public void demitir(Funcionario funcionario);
}
