package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum UnidadeFederativa {
    //Definindo constantes e atributos
    BAHIA("Bahia", "BA"),
    SAO_PAULO("São Paulo", "SP"),
    RIO_DE_JANEIRO("Rio de Janeiro", "RJ");
    
    private String estados;
    private String uf;

    //Método construtor
    private UnidadeFederativa(String estados, String uf) {
        this.estados = estados;
        this.uf = uf;
    }

    //Método getter
    public String getEstados() {
        return estados;
    }

    public String getUf() {
        return uf;
    }  
}
