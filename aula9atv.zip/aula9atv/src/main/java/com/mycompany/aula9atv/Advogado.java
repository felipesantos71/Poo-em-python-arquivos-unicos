package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Advogado extends Funcionario{
    //Definindo atributos
    private String oab;
    
    //Construtor
    public Advogado(String oab, String nome, String cpf, String rg, String dataNascimento, double salario, Sexo sexo, Setor setor, Endereco endereco) {
        super(nome, cpf, rg, dataNascimento, salario, sexo, setor, endereco);
        this.oab = oab;
    }

    //Método getter e setter
    public String getOab() {
        return oab;
    }

    public void setOab(String oab) {
        this.oab = oab;
    }

    //Método tostring()
    @Override
    public String toString() {
        return "\nAdvogado" +
                super.toString() +
                "\nOAB:" + oab ;
    }

    //Método da interface salario final
    @Override
    public double getSalarioFinal() {
        double salarioFinal = 0;
        salarioFinal = salario;
        return salarioFinal;
    }
}
