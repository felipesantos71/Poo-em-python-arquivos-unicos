/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula9atv;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        //Instanciando classes
        Advogado advogado = new Advogado("25416486", "Patricia", "54164698-26", "4196654-63", "12/12/1991", 6000.0, Sexo.FEMININO, Setor.JURIDICO,
                new Endereco("Rua T", "23", "Proximo ao V", "46265-366", "Salvador", UnidadeFederativa.BAHIA));
        Motorista motorista = new Motorista("51654165465", "Nestor", "35146541654", "2515456-63", "21/02/1990", 5000.0, Sexo.MASCULINO, Setor.OPERACOES,
                new Endereco("Rua O", "69", "Proximo a Oi", "462565-365", "Camacari", UnidadeFederativa.BAHIA));
        Gerente gerente = new Gerente(Bonificacao.GERENTE, "Lazaro", "36216546-37", "52164645-36", "25/05/1985", 8000.0, Sexo.MASCULINO, Setor.OPERACOES,
                new Endereco("Rua K", "32", "Proximo a vivo", "6454988-669", "Bota Fogo", UnidadeFederativa.RIO_DE_JANEIRO));
        Diretor diretor = new Diretor(Bonificacao.DIRETOR, "Flavia", "62654651-69", "65465465-89", "16/05/1974", 15000.0, Sexo.FEMININO, Setor.RECURSOS_HUMANOS,
                new Endereco("Rua M", "64", "Proximo a vivo", "41659-669", "Sao Paulo", UnidadeFederativa.SAO_PAULO));
        
        //Exibindo dados
        System.out.println("\n=Relatorio=\n");
        System.out.println(advogado);
        System.out.println("=Relatorio=");
        System.out.println(motorista);
        System.out.println("=Relatorio=");
        System.out.println(gerente);
        System.out.println("=Relatorio=");
        System.out.println(diretor);
        
        
    }
}
