package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Gerente extends CargoDeConfianca{

    //Método construtor
    public Gerente(Bonificacao bonificacao, String nome, String cpf, String rg, String dataNascimento, double salario, Sexo sexo, Setor setor, Endereco endereco) {
        super(bonificacao, nome, cpf, rg, dataNascimento, salario, sexo, setor, endereco);
                  
    }

    //Método da interface salario final
    @Override
    public double getSalarioFinal() {
        double salarioFinal = 0;
        salarioFinal = super.salario * super.bonificacao.getValor();
        salarioFinal += super.salario;
        return salarioFinal;
    }

    //Método tostring
    @Override
    public String toString() {
        return "\nGerente" +
                super.toString();
    }   
}
 