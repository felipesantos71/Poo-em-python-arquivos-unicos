package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Diretor extends CargoDeConfianca implements Contratacao{
    //Defindo variavel
    double PREMIO = 0.5;

    //Método construtor
    public Diretor(Bonificacao bonificacao, String nome, String cpf, String rg, String dataNascimento, double salario, Sexo sexo, Setor setor, Endereco endereco) {
        super(bonificacao, nome, cpf, rg, dataNascimento, salario, sexo, setor, endereco);
    }
   
    //Metodo da interface salario final
    @Override
    public double getSalarioFinal() {
        double salarioFinal = 0;
        salarioFinal = (super.salario * super.bonificacao.getValor() + (super.salario * PREMIO));
        salarioFinal += super.salario;
        return salarioFinal;
    }

    //Método da interface contratacao
    @Override
    public void admitir(Funcionario funcionario) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void demitir(Funcionario funcionario) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //Método tostring()
    @Override
    public String toString() {
        return "\nDiretor" + 
                super.toString() +
                "\nPremio: " + PREMIO;
    }
}
