package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum Bonificacao {
    //Definindo atributos
    GERENTE(0.35),
    DIRETOR(0.45);
    
    private double valor;
    //Método Construtor
    private Bonificacao(double valor) {
        this.valor = valor;
    }

    //Método getter
    public double getValor() {
        return valor;
    }
}
