package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum Sexo {
    //Definindo constates e atributos
    MASCULINO("Masculino"),
    FEMININO("Feminino");
    
    private String genero;

    //Método construtor
    private Sexo(String genero) {
        this.genero = genero;
    }

    //Método getter
    public String getGenero() {
        return genero;
    }   
}
