package com.mycompany.aula9atv;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public abstract class CargoDeConfianca extends Funcionario{
    //Definindo atributos
    protected Bonificacao bonificacao;

    //Método construtor
    public CargoDeConfianca(Bonificacao bonificacao, String nome, String cpf, String rg, String dataNascimento, double salario, Sexo sexo, Setor setor, Endereco endereco) {
        super(nome, cpf, rg, dataNascimento, salario, sexo, setor, endereco);
        this.bonificacao = bonificacao;
    }

    //Método getter e setter
    public Bonificacao getBonificacao() {
        return bonificacao;
    }

    public void setBonificacao(Bonificacao bonificacao) {
        this.bonificacao = bonificacao;
    }
 
}
